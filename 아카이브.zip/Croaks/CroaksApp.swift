//
//  CroaksApp.swift
//  Croaks
//
//  Created by Giwoo Kim on 5/16/24.
//

import SwiftUI

@main
struct CroaksApp: App {
    var body: some Scene {
        WindowGroup {
          MainView()
        }
    }
}
