//
//  ContentView.swift
//  Croaks
//
//  Created by Giwoo Kim on 5/16/24.
//

import SwiftUI

struct MainView : View {
    @State var todayState = "주의요함"
    @State var gageState : CGFloat = 0
    @State var numberOfNotification =  32
    @State var numberOfFix = 18
    @State var rateOfFix = 0
    @State var todaysMainPosture = "앉는자세"
    @State var currentDateFormatted: String?
    @State var buttonSelection = 0
    @State var sliderBarStatusMsg = "자세를 자주 바꿔주세요. 개굴"
    @State  var xOffset : CGFloat = 0
    @State var  yOffset : CGFloat = 0
    
    var body: some View {
        
        VStack {
            HStack{
                Text("Croaks")
                    .font(.custom("Pretendard", size: 32))
                    .fontWeight(.bold)
                Spacer()
                Image("goodcroak")
                
            } .padding(.top, 50)
            
            HStack{
                VStack{
                    
                    Circle()
                        .foregroundColor(buttonSelection == 0  ?.red : Color("backgroundColor")) // 점의 색상 설정
                        .frame(width: 5, height: 5)
                    
                    Button("요약") {
                        buttonSelection = 0
                    }
                }
                .padding(.trailing, 20)
                
                VStack{
                    
                    Circle()
                        .foregroundColor(buttonSelection == 1  ?.red :  Color("backgroundColor"))
                        .frame(width: 5, height: 5)
                    
                    
                    Button("자세분석") {
                        
                        buttonSelection = 1
                    }
                }
                .padding(.trailing, 20)
                
                VStack{
                    
                    Circle()
                        .foregroundColor(buttonSelection == 2  ?.red :  Color("backgroundColor")) // 점의 색상 설정
                        .frame(width: 5, height: 5)
                    
                    Button("자세습관") {
                        buttonSelection = 2
                    }
                    
                }
                Spacer()
                
                
            }
            Divider()
            HStack{
                VStack(alignment: .leading) {
                    
                    if let  currentDateFormatted {
                        Text("\(currentDateFormatted)")
                            .font(.custom("Pretendard", size: 14))
                            .foregroundColor(Color(UIColor(red: 0.68, green: 0.68, blue: 0.68, alpha: 1)))
                    }
                   VStack(alignment: .leading){
                         Text("오늘 브라운님의 자세는 ")
                           .font(.custom("Pretendard", size: 24))
                            .foregroundColor(.black) // 일반 텍스트 색상
                         Text("\(todayState)")
                           .font(.custom("Pretendard", size: 24))
                            .foregroundColor(.red) // 강조할 텍스트 색상
                        + Text("입니다")
                           .font(.custom("Pretendard", size: 24))
                            .foregroundColor(.black) // 일반 텍스트 색상
                    }
                }
                Spacer()
            }
            
            VStack{
                VStack{
                  
                    GeometryReader {geometry in
                       
                        VStack(alignment: .leading){
                          
                            ZStack{
                                RoundedRectangle(cornerRadius: 5)
                                    .frame(width: 161, height: 26)
                                    .foregroundColor(Color(UIColor(red: 1, green: 0.39, blue: 0, alpha: 0.2)))
                                
                              
                                
                                Text("자세를 자꾸 바꿔주세요.개굴")
                                    .font(.custom("Pretendard", size: 12))
                                    .foregroundColor(Color(UIColor(red: 1, green: 0.39, blue: 0, alpha: 1)))
                                    .multilineTextAlignment(.center)
                                    .padding(.vertical, 6.0)
                                
                                TriangleShape()
                                      .fill(Color(UIColor(red: 1, green: 0.39, blue: 0, alpha: 0.2))) // 삼각형 색상 설정
                                      .frame(width: 10, height: 10) // 삼각형 크기 설정
                                      .offset(x: 0, y: 18) // 삼각형 위치 설정
                                
                            }
                            .offset(x: xOffset, y: yOffset)
                            
                            
                            Slider(value: $gageState).frame(width: geometry.size.width, height: geometry.size.height)
                        }
                        .onChange(of: gageState) {
                            xOffset = geometry.size.width * gageState - 82
                            print(xOffset)
                            if xOffset <= 0 { xOffset = 0 }
                            if xOffset >= geometry.size.width - 160
                            {
                                xOffset =  geometry.size.width - 160
                            }
                        
                        }
                    }.frame(width: 353, height: 60)
                  
                                    
                    
                }.padding(.bottom,40 )
                
                HStack{
         
                    GroupBox{
                        HStack{
                            VStack{
                                Text("알림횟수")
                                    .font(.custom("Pretendard", size: 12))
                                    .foregroundColor(Color(UIColor(red: 0.69, green: 0.69, blue: 0.69, alpha: 1)))
                                Text("\(numberOfNotification)")
                                    .font(.custom("Pretendard", size: 26))
                            }
                            .frame(width: 100)
                            
                            Divider()
                                .frame(height: 60)
                            VStack{
                                Text("이행횟수")
                                    .font(.custom("Pretendard", size: 12))
                                    .foregroundColor(Color(UIColor(red: 0.69, green: 0.69, blue: 0.69, alpha: 1)))
                                Text("\(numberOfFix)")
                                    .font(.custom("Pretendard", size: 26))
                            }
                            .frame(width: 100)
                            
                            Divider()
                                .frame(height: 60)
                            VStack{
                                Text("이행율")
                                    .font(.custom("Pretendard", size: 12))
                                    .foregroundColor(Color(UIColor(red: 0.69, green: 0.69, blue: 0.69, alpha: 1)))
                                Text("\(rateOfFix, specifier: "%.0f")%")
                                    .font(.custom("Pretendard", size: 26))
                            }
                            .frame(width: 100)
                            
                        }
                    }
                    .frame(width: 358, height: 80)
                    .groupBoxStyle(TransparentGroupBox())
                    .padding(.bottom, 20)
                    
               
                }
                
                //이미지 그룹박스
                GroupBox {
                
                    
                    VStack {
                        HStack{
                            Text("오늘의 나의주요 자세")
                                .font(.custom("Pretendard", size: 20))
                            Spacer()
                            ZStack{
                                Rectangle()
                                    .frame(width: 76, height: 29)
                                    .foregroundColor(Color(UIColor(red: 1, green: 0.39, blue: 0, alpha: 0.2)))
                                    .cornerRadius(7)
                                Text(todaysMainPosture)
                                    .font(.custom("Pretendard", size: 14))
                                    .foregroundColor(Color(UIColor(red: 1, green: 0.39, blue: 0, alpha: 1)))
                                    .cornerRadius(3)
                            }
                            
                        }
                        
                        Image( "croak.sit") // 예시 그림 (systemName은 SF Symbols 이름)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 112, height: 198)
                            .padding()
                             
                        
                        GroupBox {
                            Text("""
                                 물가에부족 인터넷을 비추다.\n현상의 개장의 앞두던 속에 기업체가 정치를 전달하다.\n거기의 그러나 오후로 소개하게 많이 이뤄지다.
                                 """ )
                                .frame(width: 326, height: 66)
                                .multilineTextAlignment(/*@START_MENU_TOKEN@*/.leading/*@END_MENU_TOKEN@*/)
                                .font(.custom("Pretendard", size: 14))
                        }  .groupBoxStyle(TransparentGroupBox())
                            
                    }
                }
            }
            .frame(width: 358)
            .groupBoxStyle(TransparentGroupBox())
            .onAppear{
                
                let formatter = DateFormatter()
             
                formatter.locale = Locale(identifier: "ko_KR") // 한국어 로케일 설정
                formatter.dateFormat = "M월 d일" // 날짜 형식 설정
                currentDateFormatted = formatter.string(from: Date())
                
            }
            .padding()
            Spacer()
        }
        .padding()
        .background(Color("backgroundColor"))
    }
    
}
struct TransparentGroupBox: GroupBoxStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.content
            .frame(maxWidth: .infinity)
            .padding()
            .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
    }
}

    
    
    func path(in rect: CGRect) -> Path {
        
        var path = Path()
        
    
        let point1 = CGPoint(x: rect.minX, y: rect.minY)
     
        let point2 = CGPoint(x: rect.midX, y: rect.maxY)
        // 점3: 오른쪽 아래
        let point3 = CGPoint(x: rect.maxX, y: rect.minY)
        
        path.move(to: point1)
        path.addLine(to: point2)
        path.addLine(to: point3)
        path.closeSubpath()
        
        return path
    }


struct TriangleShape: Shape {
    func path(in rect: CGRect) -> Path {
        var path = Path()
        
        // 삼각형을 그리는 로직
        path.move(to: CGPoint(x: rect.minX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.midX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.minY))
        path.closeSubpath()
        
        return path
    }
}

#Preview {
    MainView()
}
